let abbreviazioni = document.getElementsByClassName('abbreviazioni')

for (let abbreviazione of abbreviazioni) {
    let espansione = abbreviazione.nextElementSibling;
    abbreviazione.style.display = 'none';
    espansione.style.color = "red";
    espansione.addEventListener('click',
    function() {
        espansione.style.display = 'none'
        abbreviazione.style.display = 'inline-block' 
    })

    abbreviazione.addEventListener('click',
    function() {
        abbreviazione.style.display = 'none' 
        espansione.style.display = 'inline-block'
    })
}
